
function square (x) { 
  return x*x ;
} 

console.log();
console.log("The square of " + 2 + " is " + square(2));
console.log("The square of " + 3 + " is " + square(3));

