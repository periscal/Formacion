 
const even =  x => (x % 2) === 0;

console.log('12 is even?  => ' + even(12));
console.log('5 is even?   => ' + even(5));
    


