

console.log();
console.log('[1, 5, 3].sort()       // => [' 
	       + [1, 5, 3].sort() + "]");

console.log();
console.log('[1, 5, 3].reverse()    // => [' 
	       + [1, 5, 3].reverse() + "]");

console.log();
console.log('[1, 5, 3].concat(9)    // => [' 
	       + [1, 5, 3].concat(9) + "]");
console.log('[1, 5, 3].concat(9,3)  // => [' 
	       + [1, 5, 3].concat(9,3) + "]");

console.log();
console.log("[1, 5, 3, 7].join(';')          // => " 
	       + [1, 5, 3, 7].join(';'));
console.log("[1, 5, 3, 7].join('')           // => " 
	       + [1, 5, 3, 7].join(''));

console.log();
console.log("[1, 5, 3, 5, 7].indexOf(5)      // => " 
	       + [1, 5, 3, 5, 7].indexOf(5));
console.log('[1, 5, 3, 5, 7].indexOf(5, 2)   // => ' 
	       + [1, 5, 3, 5, 7].indexOf(5, 2));


