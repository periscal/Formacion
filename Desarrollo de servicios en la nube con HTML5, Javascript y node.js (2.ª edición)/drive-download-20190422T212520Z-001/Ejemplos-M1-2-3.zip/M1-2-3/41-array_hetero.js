
let a = [1, 'a', undefined, , [1, 2]];

console.log();
console.log("let a = [1, 'a', undefined, , [1, 2]];");

console.log();
console.log('Elemento con índice 0 = ' + a[0]);
console.log('Elemento con índice 1 = ' + a[1]);
console.log('Elemento con índice 2 = ' + a[2]);
console.log('Elemento con índice 4 = ' + a[4]);

console.log();
console.log('Elemento con índice 1 = ' + a[1]);
console.log('Elemento con índice 2 = ' + a[2]);
console.log('Elemento con índice 3 = ' + a[3]);
console.log('Elemento con índice 9 = ' + a[9]);


let b = [0, [ 'a', [4, 3]], [1, 2]];

console.log();
console.log();
console.log("let b = [0, [ 'a', [4, 3]], [1, 2]];");

console.log();
console.log('Elemento b[0]         = ' + b[0]);
console.log('Elemento b[1][0]      = ' + b[1][0]);
console.log('Elemento b[1][1][0]   = ' + b[1][1][0]);
console.log('Elemento b[1][1][1]   = ' + b[1][1][1]);
console.log('Elemento b[2][0]      = ' + b[2][0]);
console.log('Elemento b[2][1]      = ' + b[2][1]);

