 
const between_0_4 =  x => 0<=x && x<=4;

console.log('3 between 0 and 4? => ' + between_0_4(3));
console.log('8 between 0 and 4? => ' + between_0_4(8));
    

