
let x = 3;

let y = 5 + x;

console.log();
console.log("variable x = " + x);
console.log("variable y = " + y);

y = y - 2;

console.log();
console.log("variable y = " + y);

x = y + z;

console.log();
console.log("variable x = " + x);
