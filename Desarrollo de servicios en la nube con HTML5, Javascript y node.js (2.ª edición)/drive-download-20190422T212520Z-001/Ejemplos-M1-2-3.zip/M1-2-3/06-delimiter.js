
// Unrecommended use of
// delimiters

let x;    let y = "Peter"

console.log();
console.log("variable x = " + x);
console.log("variable y = " + y);

x = "Hello"

console.log();
console.log("variable x = " + x);

