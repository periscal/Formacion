
let x = 3;  // Create x with value 3

console.log();
console.log("variable x = " + x);

x += 2;     // add 2 to x

console.log();
console.log("variable x = " + x);

x *= 3;      // multiply x by 3

console.log();
console.log("variable x = " + x);

x %= 4;    // reminder operator %

console.log();
console.log("variable x = " + x);


