

console.log();
console.log('[1, 5, 3, 7].slice(1, 2)    // => [' 
	       + [1, 5, 3, 7].slice(1, 2) + "]");
console.log('[1, 5, 3, 7].slice(1, 3)    // => [' 
	       + [1, 5, 3, 7].slice(1, 3) + "]");
console.log('[1, 5, 3, 7].slice(1, -1)   // => [' 
	       + [1, 5, 3, 7].slice(1, -1) + "]");

let a = [1, 5, 3, 7];

console.log();
console.log("let a = [1, 5, 3, 7];"); 

console.log();
console.log('a.splice(1, 2, 9)    // => [' 
	       + a.splice(1, 2, 9) + "]");
console.log('a                    // => [' 
	       + a + "]");

console.log();
console.log('a.splice(1,0,4,6)    // => [' 
	       + a.splice(1,0,4,6) + "]");
console.log('a                    // => [' 
	       + a + "]");

let b = [1, 5, 3];

console.log();
console.log("let b = [1, 5, 3];");

console.log();
console.log('b.push(6, 7)    // => ' 
	       + b.push(6, 7));
console.log('b               // => [' 
	       + b + "]");

console.log();
console.log('b.pop()         // => ' 
	       + b.pop());
console.log('b               // => [' 
	       + b + "]");



