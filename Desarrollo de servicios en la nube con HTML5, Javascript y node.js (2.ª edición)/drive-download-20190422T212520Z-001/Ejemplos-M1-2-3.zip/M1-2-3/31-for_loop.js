
let n = 3;   // 2^n
let res = 1;

for (let i = 0 ; i < n ; ++i) {
    res = res * 2;
}

let z = res -2;

console.log();
console.log( 'res = ' + res);
console.log( 'z = ' + z);


