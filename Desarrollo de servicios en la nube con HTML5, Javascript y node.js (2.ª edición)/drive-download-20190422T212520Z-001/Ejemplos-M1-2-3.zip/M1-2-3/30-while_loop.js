
let n = 3;    // 2^n
let res =  1;

while (0 < n) {
    res = res * 2;
    n = n - 1;
}

let z = res - 2;

console.log();
console.log( 'res = ' + res);
console.log( 'z = ' + z);


