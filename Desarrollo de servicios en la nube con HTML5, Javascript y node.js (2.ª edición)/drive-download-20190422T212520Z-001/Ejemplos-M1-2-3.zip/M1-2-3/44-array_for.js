
console.log(`
let n = [7, 4, 1, 23];
let add = 0;

for (let i=0; i < n.length; ++i){
    add += n[i];
}
`)

let n = [7, 4, 1, 23];
let add = 0;

for (let i=0; i < n.length; ++i){
    add += n[i];
}

console.log('add    // => ' + add);
