
var x = 5;              // Creates variable x with initial value 5

console.log();
console.log("variable x = " + x);

x = "Hello";          // Assigns string "Hello" to variable x

console.log();
console.log("variable x = " + x);

x = undefined;     // Assigns undefined to variable x

console.log();
console.log("variable x = " + x);

x = new Date();    // Assigns Date object to variable x

console.log();
console.log("variable x = " + x);


