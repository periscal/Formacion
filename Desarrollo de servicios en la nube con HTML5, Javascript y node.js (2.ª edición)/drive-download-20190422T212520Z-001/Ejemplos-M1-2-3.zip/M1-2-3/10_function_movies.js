
function my_preferred_movies () { 
  console.log();
  console.log("My preferred movies:");
  console.log(" - Jurassic Park by Steven Spielberg (1993)");
  console.log(" - King Kong by Merian C. Cooper (1933)");
  console.log(" - Citizen Kane by Orson Wells (1941)");
  console.log();
} 

my_preferred_movies();

