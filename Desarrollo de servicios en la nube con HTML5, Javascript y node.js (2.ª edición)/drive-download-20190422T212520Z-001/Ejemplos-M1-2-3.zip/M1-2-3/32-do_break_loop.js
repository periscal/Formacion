
let n = 3;    // 2^n
let res = 1;

do {
    if (0 >= n--) break;
    res = res * 2;
} while (true)

let z = res - 2;

console.log();
console.log( 'res = ' + res);
console.log( 'z = ' + z);


