  
  
  var x = 15;
  console.log();
  console.log( x + " Euros son " + x*1.13   + " Dolares.");
  console.log( x + " Euros son " + x*122.81 + " Yenes.");

