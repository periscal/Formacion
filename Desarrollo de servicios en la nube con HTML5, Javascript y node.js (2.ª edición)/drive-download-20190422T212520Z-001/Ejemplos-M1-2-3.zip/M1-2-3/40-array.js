
let a = [7, 4, 1, 23];

console.log();
console.log('Elemento con índice 0 = ' + a[0]);
console.log('Elemento con índice 1 = ' + a[1]);
console.log('Elemento con índice 2 = ' + a[2]);
console.log('Elemento con índice 3 = ' + a[3]);

console.log();
console.log('toString() convierte al string: ' + a.toString());

console.log();
console.log('Número de elementos del array a = ' + a.length);

a.length = 2;

console.log();
console.log('Elementos del array recortado = [' + a + "]");



