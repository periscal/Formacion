

console.log();
console.log('[7, 4, 1, 23].find(elem => elem < 3)       => ' 
	       + [7, 4, 1, 23].find(elem => elem < 3));

console.log();
console.log('[7, 4, 1, 23].findIndex(elem => elem < 3)  => ' 
	       + [7, 4, 1, 23].findIndex(elem => elem < 3));

console.log();
console.log('[7, 4, 1, 23].filter(elem => elem > 5)     => [' 
	        + [7, 4, 1, 23].filter(elem => elem > 5) + "]");

console.log();
console.log('[7, 4, 1, 23].map(elem => -elem)           => [' 
	       + [7, 4, 1, 23].map(elem => -elem) + "]");

