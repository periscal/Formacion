
let x = 2;

console.log();
console.log("variable x = " + x);

++x

console.log();
console.log("variable x = " + x);

let y = ++x + 2;

console.log();
console.log("variable x = " + x);
console.log("variable y = " + y);

let z =  y-- + 2;

console.log();
console.log("variable z = " + z);
console.log("variable y = " + y);


