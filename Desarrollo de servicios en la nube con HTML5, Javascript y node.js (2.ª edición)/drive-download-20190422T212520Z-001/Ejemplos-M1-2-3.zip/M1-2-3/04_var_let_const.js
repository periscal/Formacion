
console.log();
console.log("variable z = " + z);
console.log("variable t = " + t);

const MAX = 5;         // Defines MAX

console.log();
console.log("constant MAX = " + MAX);

let y;                 // Defines ES6 variable y

console.log();
console.log("variable y = " + y);

var z = 1, t = "Hello";   // Defines z y t
                          // with values 1 y "Hello"

console.log();
console.log("variable z = " + z);
console.log("variable t = " + t);
