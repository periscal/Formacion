

console.log(`
let n = [7, 4, 1, 23];
let add = 0;

n.forEach(elem => add += elem)
`)

let n = [7, 4, 1, 23];
let add = 0;

n.forEach(elem => add += elem)

console.log('add    // => ' + add);

