
let x = 5;         // Creates variable x with initial value 5

console.log();
console.log("variable x = " + x);

x = "Hello";          // Assigns string "Hello" to variable x

console.log();
console.log("variable x = " + x);

x = undefined;     // Assigns undefined to variable x

console.log();
console.log("variable x = " + x);

const MAX = 9;     // Creates constant MAX equal to 9

console.log();
console.log("constant MAX = " + MAX);

x = MAX;                // Assigns MAX (9) to variable x

console.log();
console.log("variable x = " + x);


